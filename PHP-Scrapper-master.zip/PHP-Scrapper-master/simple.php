<?php
    $counter = 1;
    $base_url = "https://www.sarouty.ma/fr/trouver-un-agent/recherche?page=";
    $logo_list = array();
    $title_list = array();
    $rent_list = array();
    $sale_list = array();
    $professional_list = array();
    while($counter<=7){
        $url = $base_url."".$counter;
        $html = file_get_contents($url);
        $pokemon_doc = new DOMDocument();
        libxml_use_internal_errors(TRUE);
        if(!empty($html)){ 
            $pokemon_doc->loadHTML($html);
            libxml_clear_errors(); 
            $pokemon_xpath = new DOMXPath($pokemon_doc);

            $pokemon_row = $pokemon_xpath->query('//div[@class="tiles"]/a[@class="tiles__tile"]/div[@class="tile"]/div[@class="tile__images"]/picture/source/@srcset');
            if($pokemon_row->length > 0){
                foreach($pokemon_row as $row){
                    array_push($logo_list, $row->nodeValue);
                }
            }

            $pokemon_row = $pokemon_xpath->query('//div[@class="tiles"]/a[@class="tiles__tile"]/div[@class="tile"]/div[@class="tile__content"]/div[@class="tile__main-info tile__main-info--size1"]');
            if($pokemon_row->length > 0){
                foreach($pokemon_row as $row){
                    array_push($title_list, $row->nodeValue);
                }
            }
            
            $pokemon_row = $pokemon_xpath->query('//div[@class="tiles"]/a[@class="tiles__tile"]/div[@class="tile"]/div[@class="tile__content"]/div[@class="tile__counters"]/div[@class="counter tile__counter"]/div[@class="counter__count"]');
            if($pokemon_row->length > 0){
                $count = 1;
                foreach($pokemon_row as $row){
                    $count++;
                    if($count > 3){
                        array_push($professional_list, $row->nodeValue);
                        $count = 1;
                    }
                    else{
                        if($count == 2)
                            array_push($rent_list, $row->nodeValue);
                        else if($count == 3)
                            array_push($sale_list, $row->nodeValue);
                    }
                }
            }
        }
        $counter++;
    }
    $view_data = "<head><title>🌹</title><link rel='stylesheet' href='style.css'></head><body style='background: #cecece;'><img src='Data/kisspng-propose-day-marriage-proposal-whatsapp-valentines-cartoon-couple-5a8abe60adc4f1-min.png' height='50px' width='50px' style='background: white; border-radius: 50%; position: fixed; right: 4px; top: 5px; border: 2px solid #87ea39;'><h1 style='color: #9469f7; margin-top: 70px;'>For Joseph.....  💋</h1><table style='text-align: center; width: 100%; border-collapse: collapse; font-family: cursive;'><thead style='background-color: #797979;'><tr style='height: 75px;'><td style='border: 2px solid #202020;'><b>No</b></td><td style='border: 2px solid #202020;'><b>LOGO</b></td><td style='border: 2px solid #202020;'><b>Title</b></td><td style='border: 2px solid #202020;'><b>Rent</b></td><td style='border: 2px solid #202020;'><b>Sale</b></td><td style='border: 2px solid #202020;'><b>Professional</b></td></tr></thead><tbody style='background-color: white;'>";
    for($j=0; $j<count($logo_list); $j++)
    {
        $view_data .= "<tr><td style='border: 2px solid #202020;'>".($j+1)."</td><td style='border: 2px solid #202020;'><img src='".$logo_list[$j]."' height='50px'></td><td style='border: 2px solid #202020;'>".$title_list[$j]."</td><td style='border: 2px solid #202020;'>".$rent_list[$j]."</td><td style='border: 2px solid #202020;'>".$sale_list[$j]."</td><td style='border: 2px solid #202020;'>".$professional_list[$j]."</td></tr>";
    }
    $view_data .= "</tbody></table><audio autoplay loop><source src='Data/Johnny-Drille-Romeo-Juliet-Official-Audio-.mp3'></audio></body>";
    print_r($view_data);
?>